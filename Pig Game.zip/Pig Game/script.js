'use strict';

// 1.Selecting elements
const score0 = document.querySelector('#score--0');
const score1 = document.querySelector('#score--1');
const dice = document.querySelector('.dice');
const player0 = document.querySelector('.player--0');
const player1 = document.querySelector('.player--1');
const current0 = document.getElementById('current--0');
const current1 = document.getElementById('current--1');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const btnNew = document.querySelector('.btn--new');

// 2.Starting conditions
let totalScores, currentScore, activePlayer, playing;

const init = function() {
    // Reset internal game state
    currentScore = 0;
    activePlayer = 0;
    totalScores = [0,0];
    playing = true;
    // Reset internal game state
    score0.textContent = 0;
    score1.textContent = 0;
    current0.textContent = 0;
    current1.textContent = 0;
    dice.classList.add('hidden');
    // Reset player UI states 
    player0.classList.remove('player--winner');
    player1.classList.remove('player--winner');
    player0.classList.add('player--active');
    player1.classList.remove('player--active');
};
    
init();

//3.Player switch funciton
const switchPlayer = function() {
    //Reset current player's round score
    document.getElementById(`current--${activePlayer}`).textContent = 0;
    currentScore = 0;
    //Switch active player
    activePlayer = activePlayer === 0 ? 1 : 0;
    player0.classList.toggle(`player--active`);
    player1.classList.toggle(`player--active`);
};
// 4.EVENT HANDLERS

//Display dice roll
btnRoll.addEventListener('click', function() {
    if(playing) {
        //1.Generating a random dice roll
         const randomNumber = Math.trunc(Math.random() * 6) + 1; 
        //2.Display dice
         dice.classList.remove('hidden');
         dice.src = `dice-${randomNumber}.png`
        //3.Check for rolled 1 
         if(randomNumber !== 1) {
        //Add dice to the current score
         currentScore += randomNumber
         document.getElementById(`current--${activePlayer}`).textContent = currentScore;
    } else  {
        //Switch to next player
         switchPlayer();
         }
     }
});

btnHold.addEventListener('click', function() {
    if(playing){
        //1.Add current score to active player's score
         totalScores[activePlayer] += currentScore;
        // totalscores[1] = totalscores[1] + currentScore
         document.getElementById(`score--${activePlayer}`).textContent = totalScores[activePlayer];
     
        //2. Check if player's socre is >= 100
         if(totalScores[activePlayer] >= 100) {
        //Finish the game
         playing = false;
         dice.classList.add('hidden');
        document
         .querySelector(`.player--${activePlayer}`)
         .classList.add('player--winner');
        document.querySelector(`.player--${activePlayer}`)
         .classList.remove('player--active');
         } else {
        switchPlayer();
     }
}
});

btnNew.addEventListener('click', init);


